import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
  template: `
    <!--The content below is only a placeholder and can be replaced.-->
    <div style="text-align:center" class="content">
      <h1>
        Welcome to {{title}}!
      </h1>
      <span style="display: block">{{ title }} app is running!</span>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'Dutch Treat';
}
